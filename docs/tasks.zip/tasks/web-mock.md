Для мокування даних у фронтенді (особливо в стеку Vite + React + TanStack Query / Axios) є 3 основні підходи: від найпростішого до професійного стандарту
індустрії.
──────

### Підхід 1. MSW (Mock Service Worker) — 🌟 Індустріальний стандарт

Як працює: Перехоплює реальні HTTP-запити на рівні мережі браузера (через Service Worker).
• Головний плюс: Код застосунку (axios, tanstack query, apiClient) залишається на 100% справжнім, без жодного рядка if (isMock). У DevTools у вкладці
Network ви бачите реальні запити зі статусами 200, 201, 400 тощо.
• Коли бекенд готовий — просто вимикаєте один прапорець в .env.local.

#### Як налаштувати за 3 кроки:

1.  Встановити MSW:

```bash
     pnpm --filter @repo/web add -D msw
     pnpm --filter @repo/web exec msw init public/ --save
```

2.  Описати хендлери (apps/web/src/mocks/handlers.ts):

```ts
import { http, HttpResponse, delay } from 'msw';
import type { RecipesListResponse, RecipeDetails } from '@repo/shared';

const mockRecipes: RecipeDetails[] = [
  {
    id: 'mock-1',
    title: 'Delicious Pasta',
    description: 'Easy homemade pasta',
    instructions: '1. Boil water...',
    thumb: 'https://res.cloudinary.com/demo/image/upload/sample.jpg',
    ingredients: [],
  },
];

export const handlers = [
  // Мок для GET /recipes
  http.get('*/recipes', async () => {
    await delay(300); // імітація мережевої затримки
    return HttpResponse.json<RecipesListResponse>({
      items: mockRecipes,
      total: mockRecipes.length,
      page: 1,
      totalPages: 1,
      limit: 10,
    });
  }),

  // Мок для POST /recipes
  http.post('*/recipes', async ({ request }) => {
    await delay(500);
    // Якщо відправляється FormData:
    // const formData = await request.formData();
    const newRecipe: RecipeDetails = {
      id: `mock-${Date.now()}`,
      title: 'Новий рецепт',
      description: 'Створено через мок',
      instructions: 'Інструкція...',
      thumb: 'https://res.cloudinary.com/demo/image/upload/sample.jpg',
      ingredients: [],
    };
    mockRecipes.push(newRecipe);
    return HttpResponse.json(newRecipe, { status: 201 });
  }),
];
```

3. Запустити Worker у main.tsx лише для dev-режиму:

```ts
async function enableMocking() {
// Вмикаємо моки, якщо бек не запущений або є прапорець VITE_USE_MOCKS=true
if (import.meta.env.DEV && import.meta.env.VITE_USE_MOCKS === 'true') {
const { setupWorker } = await import('msw/browser');
const { handlers } = await import('./mocks/handlers');
const worker = setupWorker(...handlers);
return worker.start({ onUnhandledRequest: 'bypass' });
}
}

    enableMocking().then(() => {
      createRoot(document.getElementById('root')!).render(<App />);
    });
```

──────

### Підхід 2. Axios Mock Adapter — Швидко і просто

Якщо не хочеться налаштовувати Service Worker, можна перехоплювати запити всередині самого apiClient через бібліотеку axios-mock-adapter.

1.  Встановити:

```bash
     pnpm --filter @repo/web add -D axios-mock-adapter
```

2.  Підключити до клієнта (apps/web/src/api/mock.ts):
    import MockAdapter from 'axios-mock-adapter';
    import { apiClient } from './client';

```ts
export function initAxiosMock() {
  if (import.meta.env.DEV && import.meta.env.VITE_USE_MOCKS === 'true') {
    const mock = new MockAdapter(apiClient, { delayResponse: 400 });

    mock.onGet('/recipes').reply(200, {
      items: [{ id: '1', title: 'Mock Recipe' }],
      total: 1,
    });

    mock.onPost('/recipes').reply(201, {
      id: '2',
      title: 'Created Recipe',
    });

    // Інші запити пропускати на справжній сервер:
    mock.onAny().passThrough();
  }
}
```

3. Викликати initAxiosMock() у main.tsx.
   ──────

### Підхід 3. Локальний JSON / Mock функції прямо в recipes.api.ts (Найпримітивніший)

Без встановлення додаткових бібліотек:

```ts
const USE_MOCKS = true; // або з env

export const recipesApi = {
  getAll: async (): Promise<RecipesListResponse> => {
    if (USE_MOCKS) {
      await new Promise((res) => setTimeout(res, 300));
      return {
        items: [{ id: '1', title: 'Mock Pasta' }],
        total: 1,
        page: 1,
        totalPages: 1,
        limit: 10,
      };
    }
    const { data } = await apiClient.get('/recipes');
    return data;
  },
};
```

Мінус: Доводиться додавати if (USE_MOCKS) у кожен метод, що засмічує чистий код API.
──────

### Рекомендація:

Для нашого проєкту найкраще обрати MSW (Підхід 1), тому що:

1. Ви використовуєте спільні типи з @repo/shared — моки гарантовано відповідатимуть бекенд-контракту.
2. Ці ж самі MSW-хендлери можна перевикористати у Vitest тестах та Storybook stories!
3. Для перемикання між реальними даними та моками достатньо змінити один рядок у .env.local: VITE_USE_MOCKS=true.
