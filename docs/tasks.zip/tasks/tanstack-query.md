Ось покроковий, готовий до продакшену гайд, як налаштувати TanStack Query (v5) у нашому додатку apps/web з підтримкою крос-доменних запитів до Render.
──────

### Крок 1. Встановити залежності

У папці apps/web (або з кореня):

```bash
pnpm --filter @repo/web add @tanstack/react-query axios
pnpm --filter @repo/web add -D @tanstack/react-query-devtools
```

──────

### Крок 2. Базовий HTTP-клієнт (api.ts) з credentials

Створюємо єдиний екземпляр Axios (або обгортку над Fetch), який знає URL бекенда і завжди передає куки:

```ts
// apps/web/src/shared/api/client.ts
import axios from 'axios';

export const apiClient = axios.create({
  // Береться з .env (Vite): http://localhost:4000 або https://project-kung-food-pandas.onrender.com
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:4000',
  withCredentials: true, // КРИТИЧНО для міждоменних сесій Better Auth!
  headers: {
    'Content-Type': 'application/json',
  },
});
```

──────

### Крок 3. Налаштувати QueryClient та QueryClientProvider

Найкраще винести конфігурацію клієнта в окремий файл або підключити безпосередньо в корінь React:

```tsx
// apps/web/src/main.tsx (або App.tsx)
import React from 'react';
import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import App from './App';

// Налаштовуємо розумні дефолтні параметри кешування
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 хвилин дані вважаються свіжими (без зайвих повторних запитів)
      gcTime: 1000 * 60 * 30, // 30 хвилин зберігати в кеші пам'яті (Garbage Collection)
      retry: 1, // якщо запит впав — повторити лише 1 раз
      refetchOnWindowFocus: false, // не спамити бекенд при кожному перемиканні вкладок браузера
    },
  },
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      {/* Devtools для візуалізації кешу в розробці (в production вимикається сам) */}
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  </React.StrictMode>,
);
```

──────

### Крок 4. Приклади використання (як це виглядає в компонентах)

#### 1. Отримання даних: список рецептів з пагінацією та фільтрами

TanStack Query сам відстежує зміну page чи category. Коли користувач змінює фільтр — автоматично робиться новий запит і оновлюється кеш:

```ts
// apps/web/src/features/recipes/api/useRecipes.ts
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/shared/api/client';

interface RecipeFilterParams {
  page?: number;
  limit?: number;
  category?: string;
  ingredient?: string;
  area?: string;
}

export function useRecipes(params: RecipeFilterParams) {
  return useQuery({
    // queryKey — це унікальний ідентифікатор кешу.
    // При зміні params TanStack Query автоматично зробить рефетч
    queryKey: ['recipes', params],
    queryFn: async () => {
      const response = await apiClient.get('/recipes', { params });
      return response.data;
    },
  });
}
```

У компоненті сторінки:

```tsx
function RecipesPage() {
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState('');

  const { data, isLoading, isError } = useRecipes({ page, category });

  if (isLoading) return <div>Завантаження рецептів...</div>;
  if (isError) return <div>Помилка завантаження!</div>;

  return (
    <div>
      {data.recipes.map((recipe) => (
        <RecipeCard key={recipe.id} recipe={recipe} />
      ))}
      <Pagination page={page} total={data.totalPages} onPageChange={setPage} />
    </div>
  );
}
```

──────

#### 2. Мутація: Додати/видалити з улюблених з авто-інвалідацією кешу

Коли користувач клікає на сердечко, useMutation відправляє запит і автоматично наказує TanStack Query оновити всі списки, де ці дані фігурують:

```ts
// apps/web/src/features/recipes/api/useFavoriteMutation.ts
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/shared/api/client';

export function useToggleFavorite() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ recipeId, isFavorite }: { recipeId: string; isFavorite: boolean }) => {
      if (isFavorite) {
        return apiClient.delete(`/recipes/${recipeId}/favorite`);
      } else {
        return apiClient.post(`/recipes/${recipeId}/favorite`);
      }
    },
    onSuccess: () => {
      // Автоматично скинути старий кеш: компоненти самі фоном підтягнуть свіжі дані!
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-favorites'] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
  });
}
```

──────

### Підсумок

З цим налаштуванням:

• Усі запити автоматично йдуть з credentials: true (кука сесії Better Auth надсилається на Render автоматично).
• Стан завантаження (isLoading), помилки (error) та пагінація працюють "з коробки".
• Повний порядок з кешем і жодного бойлерплейту, як у Redux.
