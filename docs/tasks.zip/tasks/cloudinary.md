## Cloudniary + React + StyleX: як завантажувати картинки для Retina (1x, 2x, 3x) без ручного зберігання трьох окремих файлів



> чи можна завантажити на cloundinary картинки для dpi x3 or x2 то як потом в react + stylex зробити завантаження картинки для x1 ?

Вам НЕ потрібно вручну зберігати 3 окремі файли на Cloudinary!

Найпотужніша фішка Cloudinary — це динамічна трансформація зображень на льоту через URL.
Ви завантажуєте на Cloudinary одне якісне оригінальне зображення (наприклад, з високою роздільною здатністю під @3x), а для @1x, @2x, @3x Cloudinary сам
оптимізує і віддасть потрібний розмір, якщо додати спеціальні параметри в посилання:

• dpr_1.0 (або w_350)
• dpr_2.0 (або w_700)
• dpr_3.0 (або w_1050)
• f_auto,q_auto (автоматично конвертує у WebP/AVIF і стискає без втрати якості).
──────

### Як це реалізувати в React + StyleX

У сучасному вебі вибір роздільної здатності екрана браузером робиться через стандартний HTML5 атрибут srcSet та дескриптори 1x, 2x, 3x. Браузер сам визначає
DPI екрана користувача і завантажує лише одне потрібне зображення.

#### 1. Утиліта для побудови Cloudinary URL

Створюємо просту хелпер-функцію, яка підставляє параметри ширини та DPR:

```ts
// apps/web/src/shared/utils/cloudinary.ts

export function getCloudinaryUrl(
  originalUrl: string,
  options: { width?: number; dpr?: number } = {},
): string {
  if (!originalUrl || !originalUrl.includes('cloudinary.com')) {
    return originalUrl;
  }

  const { width, dpr = 1 } = options;
  const transformations = ['f_auto', 'q_auto', `dpr_${dpr.toFixed(1)}`];

  if (width) {
    transformations.push(`w_${width}`, 'c_fill');
  }

  const transformString = transformations.join(',');

  // Вставляємо трансформації після /upload/
  return originalUrl.replace('/upload/', `/upload/${transformString}/`);
}
```

──────

#### 2. Компонент RecipeImage.tsx з підтримкою Retina (1x / 2x / 3x) + StyleX

```tsx
// apps/web/src/shared/ui/RecipeImage.tsx
import * as stylex from '@stylexjs/stylex';
import { getCloudinaryUrl } from '@/shared/utils/cloudinary';

const styles = stylex.create({
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
    borderRadius: 8,
    display: 'block',
  },
});

interface RecipeImageProps {
  src: string;
  alt: string;
  width?: number; // базовий розмір відображення в CSS (наприклад, 350)
  xstyle?: stylex.StyleXStyles;
}

export function RecipeImage({ src, alt, width = 350, xstyle }: RecipeImageProps) {
  // Генеруємо URL під різну щільність пікселів
  const src1x = getCloudinaryUrl(src, { width, dpr: 1 });
  const src2x = getCloudinaryUrl(src, { width, dpr: 2 });
  const src3x = getCloudinaryUrl(src, { width, dpr: 3 });

  return (
    <img
      src={src1x} // фолбек для старіших браузерів
      srcSet={`${src1x} 1x, ${src2x} 2x, ${src3x} 3x`} // браузер САМ вибере x1, x2 чи x3!
      alt={alt}
      loading="lazy"
      decoding="async"
      {...stylex.props(styles.image, xstyle)}
    />
  );
}
```

──────

### Як це працює для користувача:

1. Звичайний монітор (FullHD 1080p, DPI = 1x):
   • Браузер завантажить dpr_1.0 (легкий файл, наприклад 30 KB).
2. MacBook Retina або більшість смартфонів (DPI = 2x):
   • Браузер завантажить dpr_2.0 (чітке зображення).
3. Флагманські смартфони iPhone Pro / Samsung Ultra (DPI = 3x):
   • Браузер завантажить dpr_3.0 (ідеальна якість без мила).

### Висновок:

Вам достатньо залити на Cloudinary одне велике фото. Далі f_auto,q_auto,dpr_1.0 згенерує ідеальну оптимізовану версію для 1x автоматично.

────────────────────────────────────────────────────────────

> це картинки категорій рецептів і вони різної ширини, але висота однакова. на десктоп і таблет висота одна (369px), а ширина різна по сітці (desktop 325px,
> 590px. tablet 342px, 704px). на мобільному міняється ще й висота (250px) а ширина 343px. але в мене є думка зробити резиновий дизайн з граничними по девайсам.
> і посилання на картинки я хочу зберігати в базі. то як краще зробити?

Це чудова та зріла архітектурна думка. Ось як це робиться за найкращими стандартами індустрії (без хардкоду розмірів у базі та з повною адаптивністю).
──────

### 1. Що саме зберігати в базі даних (Бекенд)

│ Золоте правило: У базі даних ніколи не зберігають готові розміри або srcSet.
У базі ви зберігаєте одне чисте оригінальне посилання на картинку високої якості (найбільший розмір, який у вас є, наприклад, 1400px завширшки):

```json
{
  "id": "cat_1",
  "name": "Beef",
  "img": "https://res.cloudinary.com/demo/image/upload/v12345/categories/beef.jpg",
  "imgId": "kfp/categories/beef.jpg"
}
```

Чому так?
Якщо завтра дизайнер змінить сітку з 369px на 380px, вам не доведеться мігрувати базу даних. Бекенд просто віддає чистий img, а фронтенд сам формує
адаптивні розміри.
──────

### 2. Секрет адаптивності: підхід <picture> + CSS aspect-ratio

Оскільки у вас змінюються пропорції між девайсами:
• Мобілка: 343px × 250px (пропорція ~ 1.37:1)
• Планшет/Десктоп: висота фіксована 369px, а ширина гумова від 325px до 704px
Для таких випадків у HTML створено тег <picture> разом із медіа-запитами, а в CSS — object-fit: cover та StyleX.
──────

### 3. Готовий компонент CategoryCardImage.tsx (React + StyleX)

Ось компонент, який враховує:

1. Гумову сітку (fluid).
2. Різну висоту на mobile (250px) та tablet/desktop (369px).
3. Retina-екрани (1x, 2x).
4. Cloudinary авто-формат (f_auto,q_auto) і кроп (c_fill,g_auto — обрізає по центру/головному об'єкту).

```ts
     // apps/web/src/features/categories/ui/CategoryImage.tsx
     import * as stylex from '@stylexjs/stylex';
     import { breakpoints } from '@/styles/tokens.stylex';

    // Хелпер формування Cloudinary URL з висотою, шириною та DPR

    function buildCloudinaryUrl(url: string, { w, h, dpr = 1 }: { w: number; h: number; dpr?: number }) {
      if (!url || !url.includes('cloudinary.com')) return url;

      // c_fill - заповнює розмір, g_auto - фокусується на головному об'єкті страви
      const transform = `f_auto,q_auto,c_fill,g_auto,w_${w},h_${h},dpr_${dpr.toFixed(1)}`;
      return url.replace('/upload/', `/upload/${transform}/`);
    }

    const styles = stylex.create({
      picture: {
        display: 'block',
        width: '100%',
        height: {
          default: 250,                  // mobile висота
          [breakpoints.tablet]: 369,    // tablet висота
          [breakpoints.desktop]: 369,   // desktop висота
        },
        borderRadius: 16,
        overflow: 'hidden',
      },
      img: {
        width: '100%',
        height: '100%',
        objectFit: 'cover',             // картинка ідеально заповнює будь-яку гумову ширину без спотворень
        display: 'block',
      },
    });

    interface CategoryImageProps {
      src: string;
      alt: string;
      xstyle?: stylex.StyleXStyles;
    }

    export function CategoryImage({ src, alt, xstyle }: CategoryImageProps) {
      // 1. Tablet & Desktop: висота 369px, ширина від 325px до 704px (беремо базу 704px під Retina)
      const desk1x = buildCloudinaryUrl(src, { w: 704, h: 369, dpr: 1 });
      const desk2x = buildCloudinaryUrl(src, { w: 704, h: 369, dpr: 2 });

      // 2. Mobile: висота 250px, ширина гумова ~343px (база 375px)
      const mob1x = buildCloudinaryUrl(src, { w: 375, h: 250, dpr: 1 });
      const mob2x = buildCloudinaryUrl(src, { w: 375, h: 250, dpr: 2 });

      return (
        <picture {...stylex.props(styles.picture, xstyle)}>
          {/* Для планшетів та десктопів (від 768px і вище) */}
          <source
            media="(min-width: 768px)"
            srcSet={`${desk1x} 1x, ${desk2x} 2x`}
          />

          {/* Для мобільних пристроїв (до 768px) */}
          <source
            srcSet={`${mob1x} 1x, ${mob2x} 2x`}
          />

          {/* Фолбек img */}
          <img
            src={desk1x}
            alt={alt}
            loading="lazy"
            decoding="async"
            {...stylex.props(styles.img)}
          />
        </picture>
      );
    }
```

──────

### Чому цей підхід ідеальний:

1. База чиста: В БД один простий рядок img: "https://res.cloudinary.com/.../beef.jpg".
2. Мобільний трафік заощаджено: На телефонах завантажується компактна картинка висотою 250px.
3. Гумова верстка не ламається: Завдяки object-fit: cover картинка підлаштовується під будь-яку сітку — хоч 325px, хоч 590px, хоч 704px, не розтягуючись і  
   не зминаючись.
4. Cloudinary робить усю важку роботу: Автоматично перетворює формат на WebP/AVIF та стискає якість (q_auto).
