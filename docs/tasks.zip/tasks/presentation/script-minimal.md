# Сценарій презентації (Minimalist & High-Impact Edition)

> **Формат:** Чистий мінімалізм (Clean Dark & Accent Emerald). Мінімум слів на слайдах, максимум повітря, сильні візуальні акценти (key metrics, badges, short bullets).  
> **Спікер:** Короткі, чіткі тези без "води".

---

## 🎨 Дизайн-код (Minimalist Dark)

- **Фон:** `#0A0A0A` (глибокий монохром)
- **Картки:** `#141414` з ультратонкими рамками `rgba(255, 255, 255, 0.08)`
- **Акценти:** `#10B981` (Emerald Green) та `#FFFFFF`
- **Типографіка:** Великі контрастні заголовки (Inter / Montserrat), великі цифри, 3–4 булети на слайд максимум.

---

## 📋 Структура слайдів (11 слайдів)

```
1. Kung Food Panda ── Титул
2. Проблема & Рішення ── Чому ми це створили
3. Команда Capybara ── Хто стоїть за проєктом
4. Процес розробки ── Agile, GitHub & CI/CD
5. Frontend Стек ── Швидкість та UI-архітектура
6. Backend & Cloud Стек ── Надійність даних та безпека
7. Ключові можливості ── Що вміє платформа
8. Інженерна якість ── SEO, Performance & AI-Ready
9. Live Demo ── Демонстрація + QR-код
10. Досвід & Плани ── Версія 2.0
11. Фінал ── Дякуємо & Q&A
```

---

## Слайд 1: Kung Food Panda

- **Макет:** Центрований титул, неоновий логотип/іконка, метадані.
- **Заголовок:** `Kung Food Panda`
- **Підзаголовок:** `Платформа для кулінарної спільноти нового покоління`
- **Бейджі:** `Team Capybara` • `Fullstack Project` • `GoIT 2026`
- **AI Image Prompt:**
  > _Ultra-minimalist modern emblem of a cute stylized panda wearing a chef hat and capybara wearing a chef hat , glowing thin emerald outline, pure deep black background, clean studio lighting, 8k._
- **Текст спікера:**
  > «Вітаємо! Ми команда Capybara, і сьогодні презентуємо наш випускний проєкт — Kung Food Panda. Це сучасний веб-сервіс, який поєднує пошук рецептів, кулінарну соціальну мережу та зручний конструктор страв».

---

## Слайд 2: Проблема та Рішення

- **Макет:** Спліт 50/50: зліва «Біль», справа «Рішення».
- **Зміст:**
  - ❌ **Проблема:** Перевантажені рекламою сайти, незручний пошук за інгредієнтами, хаос у збережених рецептах.
  - ✅ **Рішення:** Мінімалістичний інтерфейс, миттєві комбіновані фільтри, збереження в один клік.
- **AI Image Prompt:**
  > _Minimal split composition: chaotic blurry cluttered interface on the left, turning into a glowing sleek clean minimalist organized recipe card on the right, dark aesthetic._
- **Текст спікера:**
  > «Більшість сайтів із рецептами сьогодні перевантажені банерами та не дають знайти страву за наявними продуктами. Ми створили швидку, чисту платформу, де користувач знаходить або створює рецепт за лічені секунди».

---

## Слайд 3: Команда Capybara

- **Макет:** Сітка карток команди з аватарами та короткими ролями.
- **Зміст:**
  - **Andrii Toptun:** Team Lead, Fullstack
  - **Dmytro Poliakov:** Scrum Master, Fullstack
  - **Ihor Yatsyshyn:** Fullstack
  - **Igor Malyshko:** Fullstack
  - **Illia Skachko:** Fullstack
  - **Dmytro Breus:** Fullstack
- **AI Image Prompt:**
  > _Group of six minimalist sleek glowing avatar silhouettes around a modern dark holographic terminal, emerald digital glow, clean tech background._
- **Текст спікера:**
  > «Наш результат — це злагоджена робота команди з 6 розробників. Ми розділили архітектуру на чіткі модулі, де кожен відповідав за свій напрямок: від бази даних до фінальної анімації на клієнті».

---

## Слайд 4: Процес розробки & CI/CD

- **Макет:** 3 горизонтальні блоки пайплайну.
- **Зміст:**
  1. 🗓️ **Agile / Scrum:** Kanban у GitHub Projects.
  2. 🌿 **Git Flow:** Feature-гілки, Pull Requests із обов'язковим Code Review.
  3. ⚙️ **Автоматизація:** GitHub Actions, Husky, Prettier, ESLint, TypeScript, Tests перевірка на кожен пуш.
- **AI Image Prompt:**
  > _Sleek dark glowing flowchart of automated CI/CD pipeline, git branch nodes glowing emerald green, floating in deep dark space, minimalist technology._
- **Текст спікера:**
  > «Ми організували роботу за класичним Agile. Кожна зміна проходила перевірку через автоматизовані CI/CD тести, лінтери та код-рев’ю колег і Team lead'а перед злиттям в основну гілку».

---

## Слайд 5: Frontend: Технології та Швидкість

- **Макет:** 4 акцентні плашки технологій із ключовою перевагою.
- **Зміст:**
  - ⚛️ **React 19 & Vite 8:** Використання найновіших можливостей React, блискавичний HMR і збірка.
  - 🎨 **Meta StyleX (`@stylexjs/stylex`):** Атомарний CSS-in-JS з нульовим runtime overhead, статичною компіляцією та надійною дедуплікацією стилів.
  - 🔄 **TanStack Query (React Query v5):** Оптимістичні оновлення, кешування серверного стану, автоматична інвалідація запитів.
  - 🧭 **React Router v7 / v8:** Маршрутизація з захищеними роутами (Protected Routes) для приватних кабінетів.
  - 📚 **Storybook 10:** Ізольована розробка та тестування UI-компонентів ще до підключення до бекенду.
  - 🎭 **Mock Service Worker (MSW 3):** Імітація серверних відповідей на клієнті для паралельної розробки фронтенду.
- **Візуальні елементи:** Логотипи React 19, StyleX, TanStack, Vite, Storybook.
- **AI Image Prompt:**
  > _Minimalistic floating metallic tech icons of React and modern UI code blocks, illuminated with subtle neon green light, dark carbon background._
- **Текст спікера:**
  > «На фронтенді ми зробили ставку на продуктивність: React 19 та Meta StyleX забезпечують швидкий запуск інтерфейсу без важких CSS-бандлів, а TanStack Query миттєво доставляє дані з кешу».

---

## Слайд 6: Backend & Cloud Інфраструктура

- **Макет:** Архітектурна схема з 4 елементів.
- **Зміст:**
  - 🚀 **Node.js 24 LTS & Express 5:** Сучасний бекенд з високою пропускною здатністю.
  - 🗄️ **PostgreSQL 18 + Prisma ORM 7:** Реляційна модель даних, повна типобезпека запитів та автоматичні міграції.
  - ⚡ **Neon Database:** Serverless PostgreSQL у хмарі з миттєвим масштабуванням та гілкуванням баз даних.
  - 🔐 **Better Auth:** Сесійна аутентифікація, захист cookie, безпечна робота з паролями та користувачами.
  - ☁️ **Cloudinary SDK:** Автоматична обробка, оптимізація розмірів та зберігання медіафайлів рецептів.
  - 📖 **OpenAPI 3.0 & Redocly / Swagger:** Автоматична генерація специфікації API із Zod-схем.
  - 🌐 **Деплой:**
    - **Frontend:** Розгорнуто на **Vercel** (Global Edge CDN).
    - **Backend API:** Розгорнуто на **Render**.
- **Візуальні елементи:** Логотипи Node.js, Prisma, PostgreSQL, Neon, Cloudinary, Vercel, Render.
- **AI Image Prompt:**
  > _Minimalist server rack and database cylinder glowing soft emerald and white, floating in dark glassmorphism space, elegant cloud connections._
- **Текст спікера:**
  > «Бекенд побудований на Express та Prisma з базою PostgreSQL. Для автентифікації ми обрали Better Auth, а медіафайли зберігаються в Cloudinary CDN з оптимізацією під мобільні пристрої».

---

## Слайд 7: Ключові можливості платформи

- **Макет:** 4 лаконічні картки функціоналу.
- **Зміст:**
  - 🔍 **Розумний каталог:** Фільтри за категоріями, кухнями світу та інгредієнтами.
  - 📖 **Картка рецепта:** Інгредієнти, час приготування, пропорції та автор.
  - ➕ **Конструктор страв:** Створення рецепта з покроковими інструкціями та фото.
  - ❤️ **Особистий простір:** Обране (Favorites), власні публікації, підписки на кулінарів.
- **AI Image Prompt:**
  > _Four minimalist sleek UI card outlines displaying recipe photo, ingredient tags, and favorite heart icon, floating over clean dark slate backdrop._
- **Текст спікера:**
  > «Основний функціонал: багаторівневий каталог страв, детальний покроковий рецепт, конструктор власних кулінарних ідей та особистий кабінет кулінара з колекцією улюбленого».

---

## Слайд 8: Інженерна якість: SEO, UX & AI-Ready

- **Макет:** 4 компактні метрики інженерних покращень.
- **Зміст:**
  - 🔗 **Human-Readable URLs (Slugs):** Читабельні адреси для категорій, рецептів і кухонь.
  - 📍 **URL Sync:** Фільтри зберігаються в адресному рядку (`useSearchParams`) — посиланням легко ділитися.
  - 👁️ **Енергоефективний UX:** Слайдери активуються лише в полі зору через `IntersectionObserver`.
  - 🤖 **AI-Ready:** Підтримка протоколів `llms.txt` та Agent Resource Discovery (`ard.json`).
- **AI Image Prompt:**
  > _Four clean glowing icons: Search Magnifier, Lightning Bolt, Shield, and Neural Brain node, arranged in a neat grid on pure dark minimalist background._
- **Текст спікера:**
  > «Ми подбали про технічну досконалість: впровадили SEO-слаги, синхронізували фільтри з URL, оптимізували продуктивність через IntersectionObserver і навіть додали специфікацію llms.txt, щоб наш сайт був зрозумілий штучному інтелекту».

---

## Слайд 9: Live Demo

- **Макет:** Великий QR-код по центру, мінімалістичний план показу.
- **Заголовок:** `Час скуштувати наживо`
- **Підзаголовок:** `Скануйте QR-код для перегляду на смартфоні`
- **Сценарій показу (2 хвилини):**
  1. Пошук рецепта через комбінований фільтр.
  2. Додавання рецепта в обране.
  3. Конструктор створення нового рецепта.
- **AI Image Prompt:**
  > _Large glowing emerald QR code surrounded by a sleek dark smartphone silhouette, minimal dark futuristic pedestal, cinematic lighting._
- **Текст спікера:**
  > «Запрошуємо протестувати продукт наживо! Наведіть камеру на QR-код, щоб відкрити сайт на смартфоні, а я продемонструю роботу на великому екрані».

---

## Слайд 10: Досвід та Плани на версію 2.0

- **Макет:** Спліт: Здобутки vs Майбутнє.
- **Зміст:**
  - 🎓 **Наш досвід:** Монорепозиторій Turborepo, строга типізація контракту `@repo/shared`, 100% тестів.
  - 🔮 **Плани 2.0:**
    - 🤖 AI-шеф: рецепти за фотографією продуктів із холодильника.
    - 🛒 Автоматичний список покупок.
    - ⏱️ Таймер готування на сторінці рецепта.
- **AI Image Prompt:**
  > _Minimal roadmap concept, straight glowing emerald line pointing to a bright point in dark space, minimal tech aesthetic._
- **Текст спікера:**
  > «Цей проєкт дав нам досвід роботи з сучасними архітектурами. Наступний крок — версія 2.0, де ми додамо AI-підбір рецептів за фотографією продуктів і розумний список покупок».

---

## Слайд 11: Дякуємо за увагу!

- **Макет:** Центрований фінал із двома QR-кодами.
- **Заголовок:** `Дякуємо за увагу!`
- **Підзаголовок:** `Готові відповісти на ваші запитання`
- **Контакти:**
  - 🐙 **QR-код 1:** GitHub Репозиторій
  - 🌐 **QR-код 2:** Live Website
- **Слоган:** _Kung Food Panda — Готуйте з пристрастю, кодіть з розумом!_
- **AI Image Prompt:**
  > _Minimalist neon outline of panda chef saying goodbye, dark elegant background, subtle ambient emerald glow, clean composition._
- **Текст спікера:**
  > «Дякуємо менторам, викладачам та аудиторії. Команда Capybara готова до ваших запитань!»
