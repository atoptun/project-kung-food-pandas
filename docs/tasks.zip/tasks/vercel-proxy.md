### Варіант 1: Vercel Rewrites (Найбільш рекомендований і надійний 🏆)

Замість того, щоб фронтенд безпосередньо звертався до project.onrender.com, ви налаштовуєте проксі на самому Vercel.

Для браузера запит іде на your-app.vercel.app/api/..., Vercel сам пересилає його на Render і повертає відповідь.
Результат: Кука стає First-Party (рідною)! Її не заблокує жоден Safari чи Incognito mode.

#### Як налаштувати:

У корені apps/web/ створіть або доповніть файл vercel.json:

```json
{
  "rewrites": [
    {
      "source": "/api/:path*",
      "destination": "https://project-kung-food-pandas.onrender.com/api/:path*"
    }
  ]
}
```

#### На фронтенді:

У better-auth/react (або axios / fetch) ви вказуєте відносний шлях:

```ts
// apps/web/src/lib/auth-client.ts
import { createAuthClient } from 'better-auth/react';

export const authClient = createAuthClient({
  // Якщо на Vercel — запити йдуть на той самий домен /api
  baseURL: import.meta.env.PROD ? window.location.origin : 'http://localhost:4000',
});
```

Жодних проблем із CORS чи блокуванням cookie взагалі не існує.
