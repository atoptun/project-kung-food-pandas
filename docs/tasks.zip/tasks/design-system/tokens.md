# Foodies Design System: Токени та глобальні константи

> Джерело: розбір бінарного макету `tasks/figma/canvas.fig` (Figma Kiwi Engine)

---

## 1. Колірна палітра (Color Palette)

Усі кольори отримано безпосередньо з оригінальних заливок (`fillPaints`) та обводок (`strokePaints`) компонентів Figma:

| Назва токену | Значення (HEX / RGBA) | Опис та застосування в інтерфейсі |
| :--- | :--- | :--- |
| `black` | `#050505` | Основний чорний колір фонів, заголовків H1-H4, активних рамок інпутів, футера та темних кнопок |
| `darkGray` | `#1A1A1A` | Темно-сірий колір карток, фону кнопок `solid`, тексту описів |
| `gray` | `#BFBEBE` | Нейтральний сірий для плейсхолдерів, бордерів інпутів за замовчуванням, лічильників символів |
| `lightGray` | `#EEEEEE` | Світло-сірий фон плашок, тегів категорій, випадаючих списків |
| `border` | `#E8E8E8` | Розділювальні лінії, контури карток рецептів, бордери круглих кнопок (`Button.Circle`) |
| `white` | `#FFFFFF` | Чистий білий фон сторінок, колір тексту на темних кнопках і бейджах |
| `overlayDark` | `rgba(5, 5, 5, 0.2)` | Напівпрозорий темний бекдроп для модальних вікон (`Modal`) |
| `overlayLight` | `rgba(255, 255, 255, 0.2)` | Напівпрозорі білі елементи поверх зображень та градієнтів |

---

## 2. Адаптивні точки перелому (Breakpoints)

| Пристрій | Значення | Поведінка верстки |
| :--- | :--- | :--- |
| **Mobile** | `min-width: 375px` | Гумова верстка від 320px, адаптується під 375px (контейнери 343px, висота категорій 250px) |
| **Tablet** | `min-width: 768px` | 2-колонкова сітка, висота карток категорій 369px, фіксована висота кнопок 56px |
| **Desktop** | `min-width: 1440px` | 3-колонкова асиметрична сітка, максимальна ширина контенту 1200-1280px |

---

## 3. Типографіка (Typography Hierarchy)

Основний шрифт проєкту: **`Mulish`** (змінний шрифт `@fontsource-variable/mulish`).  
Усі розміри наведені у форматі `font-size / line-height`:

### Заголовки (Headings):
- **H1 (Hero / Main page titles):**
  - **Desktop (1440px):** `90px / 90px` (-0.02em, ExtraBold 800)
  - **Tablet (768px):** `70px / 70px` (-0.02em, ExtraBold 800)
  - **Mobile (375px):** `40px / 40px` (-0.02em, ExtraBold 800)
- **H2 (Section titles, Categories, Testimonials):**
  - **Desktop & Tablet:** `40px / 44px` (-0.02em, ExtraBold 800)
  - **Mobile:** `28px / 32px` (-0.02em, ExtraBold 800)
- **H3 (Recipe cards, Modal titles, Subsections):**
  - **Desktop & Tablet:** `24px / 28px` (-0.02em, ExtraBold 800 або Bold 700)
  - **Mobile:** `18px / 24px` (-0.02em, ExtraBold 800)
- **H4 (Small cards, Tab items, Dropdown headers):**
  - **Desktop & Tablet:** `20px / 24px` (-0.02em, Bold 700 / ExtraBold 800)
  - **Mobile:** `18px / 22px` (-0.02em, Bold 700)

### Основний та допоміжний текст (Body & Captions):
- **Main (Body text, Inputs, Descriptions):**
  - **Desktop & Tablet:** `16px / 24px` (Medium 500)
  - **Mobile:** `14px / 20px` (Medium 500)
- **Main Bold (Button labels, Author names, Active tabs):**
  - **Desktop & Tablet:** `16px / 24px` (Bold 700)
  - **Mobile:** `14px / 20px` (Bold 700)
- **Caption / Small (Badges, character counter, ingredient quantity):**
  - **Усі екрани:** `12px / 18px` (Medium 500 або Bold 700)

---

## 4. Радіуси заокруглення (Border Radius)

- **Кнопки (`Button`, `Button.Circle`):** `30px` (повне скруглення / pill shape)
- **Картки категорій та рецептів:** `16px`
- **Модальні вікна (`Modal`):** `30px` (десктоп/планшет) та `24px` (мобільні)
- **Аватарки користувачів:** `100px` (коло `50%`)
