# Figma Images & Assets Map

Звʼязка хешів зображень із папки `tasks/figma/images/` з елементами макета:

| Hash файлу в tasks/figma/images | Назва у макеті | Базові розміри (W x H) | Категорія |
| :--- | :--- | :--- | :--- |
| `6f42424c217b1923e78563834fe0c631e2c5990b` | **Desserts** | 590 × 369 px | Категорія страви |
| `8a00a6ab218308735f2895809fa5a64dd14937a5` | **Beef** | 325 × 369 px | Категорія страви |
| `86c1788e1f53b00bceb1fe70f27292a8af8ed741` | **Breakfast** | 325 × 369 px | Категорія страви |
| `da2d1e525c2c52198653612d7615c56812248f5f` | **Goat** | 325 × 369 px | Категорія страви |
| `4486f78d035fe25c49571cce9d298ed1887ddaeb` | **Lamb** | 590 × 369 px | Категорія страви |
| `66a74ee62a2e5c1842f1a32261d3750738b6cdf8` | **Miscellaneous** | 325 × 369 px | Категорія страви |
| `38dbd2c1f9b792bfdcc8fb541cf9d7a933e9c3ab` | **Pasta** | 325 × 369 px | Категорія страви |
| `eb7f5da470eebcf47422461b89a9956f43a5d276` | **Pork** | 590 × 369 px | Категорія страви |
| `b03defd9437f92ee857319607b19c72e3c6c4096` | **Seafood** | 325 × 369 px | Категорія страви |
| `6483275e4a5735fbb4aa6ac3392cecdb584faaff` | **Side** | 590 × 369 px | Категорія страви |
| `018b17ac39e9876fcfb639a3fca3ae8796924e8a` | **Starter** | 325 × 369 px | Категорія страви |
| `3b72f3ab2b2cc7542a28231047f89ab2474db377` | **Vegan** | 633 × 369 px | Категорія страви |
| `ae1f3f3220d400a1794cfc4226e3b6e901d0aa30` | **Vegetarian** | 619 × 417 px | Категорія страви |
| `f03434b20d2b1fb9dafdbef4ecb99b302e98bfeb` | **image** | 551 × 400 px | Інше / Фото |
| `0776818603c11c493a7ab1644976e03d6a70a1a7` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `03d9b08554dc9174cc6be308df8a2dc47df27297` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `99b6c526f76422525151f68e1c0cc21b0d3a7678` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `a728301bcba4075b28ad4b884a0d710e4b6704a4` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `5a78f5c6b0105e4b9f800ea3c992f57bd65bfad1` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `93639552ec970ba5e89e6ee099676a68a5333c77` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `0810d49b6bb63a51831d1debeb656c1cf639b7c1` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `fbea244ba4a2d406f2bda8ff9b9be1079f880de1` | **image 4** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `4f575e5f37e177eaeca331e1917a6f0665df2316` | **image** | 50 × 50 px | Інше / Фото |
| `b211921d2af5c7a8bf64f8977ed4c03cf630696b` | **image** | 120 × 120 px | Інше / Фото |
| `c675d4d8ceb7d318683d7925cff3f4937630360c` | **image** | 100 × 100 px | Інше / Фото |
| `8a9467de74ecdc9d3e1b639dd0cd93aca8f67c4f` | **image** | 100 × 100 px | Інше / Фото |
| `89377c47eccd8c0a87eaa97d4fd30832b87e5442` | **image** | 100 × 100 px | Інше / Фото |
| `ec05360337772319d67547a912306105e025f196` | **image** | 100 × 100 px | Інше / Фото |
| `a138886325ad89af89ab37520ad27f59951aceeb` | **image** | 100 × 100 px | Інше / Фото |
| `1c04ebe1007aefad31bb7b20f06c2f2bf9d591d7` | **image** | 100 × 100 px | Інше / Фото |
| `1039dd9f0fb9f7f633f4eb308243c17ec05d7de7` | **image** | 100 × 100 px | Інше / Фото |
| `33cf4650911688f9f89d369770cb519d1c7f2cc6` | **image** | 100 × 100 px | Інше / Фото |
| `c0dc2246e50f042c84d406619f6926d72d3393bf` | **image** | 290 × 275 px | Інше / Фото |
| `10794ade56f5a24a9d37f5b4818a64bc6f42af21` | **image** | 40 × 40 px | Інше / Фото |
| `aded0639ca132c9a6a09fa98cecf6bee44dcb7e2` | **image** | 305 × 275 px | Інше / Фото |
| `603e91a7901bfb4c817be5b38cd1ed7b46496c9c` | **image** | 100 × 100 px | Інше / Фото |
| `fad34a20a494cebf160f332faad97ced474c5b4e` | **image** | 100 × 100 px | Інше / Фото |
| `96fc758a0ac5baa3c86b73bba0ec1747126ac002` | **image** | 100 × 100 px | Інше / Фото |
| `347fa3bd180a325781f76ac54ae8476f45991e31` | **image** | 100 × 100 px | Інше / Фото |
| `cc7c838cb8f55a16b0b4192474231b454482da42` | **image** | 100 × 100 px | Інше / Фото |
| `969858b05e69cb2589e3af62bf6b857f47f73432` | **image** | 100 × 100 px | Інше / Фото |
| `f166e81a9d8d997c16da358e9f01b0e2de49f501` | **image** | 100 × 100 px | Інше / Фото |
| `1b5d5470611e32ee9249fcb5ec52ebaedc92a905` | **image** | 100 × 100 px | Інше / Фото |
| `73e4465191ae266a6dadf5cb00e6591bfb5e2b10` | **image** | 302 × 273 px | Інше / Фото |
| `c2dea9c7c81d89df43aa0f8f6c89974ac7ef3b49` | **image** | 128 × 116 px | Інше / Фото |
| `abc14123451a00f01b69b94af1070e738698a31b` | **image** | 100 × 100 px | Інше / Фото |
| `7e1cec92a80855bbff9a5214a5feac1e280cf18b` | **image** | 85 × 85 px | Інше / Фото |
| `1c6df269fd2558f985cc76b1d5b0d608e31251eb` | **image** | 85 × 85 px | Інше / Фото |
| `be825da95e6640d08d65d54b4b69830550340abc` | **image** | 85 × 85 px | Інше / Фото |
| `c1c5ed538fa7f3ad01e41e871a7a8f3fa4691151` | **image** | 100 × 100 px | Інше / Фото |
| `8b8588802d39cdc7457392ed8725fff74b7f7ab6` | **image** | 85 × 85 px | Інше / Фото |
| `827a97390725725c556d2ad8f4accfdfb4716242` | **image** | 85 × 85 px | Інше / Фото |
| `000ee61bad0b366ae90b9ab8e7f7dcd86820699b` | **image** | 100 × 100 px | Інше / Фото |
| `415e1cf539760c2f909a304999b6b8eece3c0928` | **image** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `b707ba27bd51c1ca26ba2c109e5e0f5574106401` | **image** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `a3c75617967abaadf1857dfae0561e2724254447` | **image** | 60 × 60 px | Аватар відгуку (Testimonial) |
| `01b0795bb774461ff70ca84c5722ec9f4fae91c0` | **Chicken** | 633 × 369 px | Інше / Фото |
| `ed506672aaaab43ecf4c157e12d55f007cc6cce0` | **Soup** | 633 × 369 px | Інше / Фото |
