Перехід з Redux на TanStack Query + Zustand у нашому проєкті дуже простий, бо Redux зараз використовується лише як RTK Query для одного запиту
(/testimonials). Жодного іншого глобального стейту в Redux ще немає.
──────

### 1. Розподіл відповідальності

• TanStack Query (React Query): Серверний стан (кешування, запити до API, рефетч, пагінація, мутації, isLoading, isError).
• Zustand: Клієнтський стан (модалки, стан бічного меню, фільтри/пошук, локальні налаштування, кошик або активні кроки оформлення).
──────

### 2. Кроки міграції

#### Крок 1. Встановити нові пакети та видалити Redux

В apps/web:

```bash
    pnpm --filter @repo/web add @tanstack/react-query zustand
    pnpm --filter @repo/web remove @reduxjs/toolkit react-redux
```

(Опціонально dev-інструмент: pnpm --filter @repo/web add -D @tanstack/react-query-devtools)
──────

#### Крок 2. Налаштувати клієнт TanStack Query (apps/web/src/api/query-client.ts)

Створити QueryClient з дефолтними налаштуваннями кешу (наприклад, credentials: 'include' для крос-доменних cookie та адекватний staleTime):

```ts
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 хвилин
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});
```

──────

#### Крок 3. Замінити RTK Query хуки на TanStack Query хуки

Замість createApi у apps/web/src/redux/api.ts створюємо HTTP-функції або хуки, наприклад у apps/web/src/api/testimonials.ts:

```ts
import { useQuery } from '@tanstack/react-query';
import type { TestimonialsListResponse } from '@repo/shared';
import { clientEnv } from '@/env';

async function fetchTestimonials(): Promise<TestimonialsListResponse> {
  const res = await fetch(`${clientEnv.VITE_API_URL}/testimonials`, {
    credentials: 'include',
  });
  if (!res.ok) throw new Error('Failed to fetch testimonials');
  return res.json();
}

export function useTestimonials() {
  return useQuery({
    queryKey: ['testimonials'],
    queryFn: fetchTestimonials,
    staleTime: 1000 * 60 * 60 * 24, // 1 день (як було в RTK)
  });
}
```

──────

#### Крок 4. Створити Zustand стори (за потреби для UI стану)

Наприклад, для кошика чи модалок apps/web/src/stores/cart.store.ts:

```ts
import { create } from 'zustand';

interface CartState {
  items: Array<{ id: string; quantity: number }>;
  addItem: (id: string) => void;
  clearCart: () => void;
}

export const useCartStore = create<CartState>((set) => ({
  items: [],
  addItem: (id) =>
    set((state) => ({
      items: [...state.items, { id, quantity: 1 }],
    })),
  clearCart: () => set({ items: [] }),
}));
```

──────

#### Крок 5. Оновити провайдер у main.tsx

Замінити <Provider store={store}> на <QueryClientProvider>:

```ts
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/api/query-client';

    createRoot(rootElement).render(
      <StrictMode>
        <QueryClientProvider client={queryClient}>
          <App />
        </QueryClientProvider>
      </StrictMode>,
    );
```

──────

#### Крок 6. Оновити сторінку home.tsx

Сигнатура майже ідентична:

```ts
// Замість: const { data, isLoading, isError } = useGetTestimonialsQuery();
const { data, isLoading, isError } = useTestimonials();
```

──────

#### Крок 7. Очистити директорію apps/web/src/redux/

Видалити теку apps/web/src/redux (api.ts, app.ts).
──────

### Підсумок

Зараз ідеальний момент для переходу: задіяно лише один ендпоінт, міграція займе близько 5 хвилин і зменшить бандл, прибравши важкий Redux Toolkit на користь
набагато гнучкішого TanStack Query + Zustand. Починаємо міграцію?
