## Zustand: модалки, меню, тоасти

Коли UI-логіка ускладнюється (наприклад, потрібно блокувати скрол сторінки, автоматично закривати меню при зміні роуту чи зміні розміру екрана, керувати
кількома модалками, або зберігати стан у `localStorage`), у Zustand використовують 4 стандартні підходи:
──────

### 1. Сайд-ефекти всередині дій (блокування скролу body)

Можна керувати DOM прямо в діях стора, щоб не писати useEffect у кожному компоненті:

```ts
export const useUIStore = create<UIState>((set) => ({
  isMobileMenuOpen: false,

  openMobileMenu: () => {
    document.body.style.overflow = 'hidden'; // блокуємо скрол сторінки
    set({ isMobileMenuOpen: true });
  },

  closeMobileMenu: () => {
    document.body.style.overflow = ''; // повертаємо скрол
    set({ isMobileMenuOpen: false });
  },
}));
```

──────

### 2. Керування взаємовиключними вікнами (меню vs модалки)

Щоб мобільне меню автоматично закривалося, якщо користувач натиснув "Увійти" (відкривається модалка):

```ts
interface UIState {
  isMobileMenuOpen: boolean;
  activeModal: 'signIn' | 'signUp' | 'logoutConfirm' | null;
  openModal: (modal: UIState['activeModal']) => void;
  closeAll: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  isMobileMenuOpen: false,
  activeModal: null,

  openModal: (modal) =>
    set({
      activeModal: modal,
      isMobileMenuOpen: false, // закриваємо меню, якщо відкрили модалку
    }),

  closeAll: () =>
    set({
      isMobileMenuOpen: false,
      activeModal: null,
    }),
}));
```

──────

### 3. Автозакриття при переході по сторінках (React Router)

У вашому кореневому лейауті або навігації один раз підписуємося на зміну URL:

```ts
// В компоненті Layout / App
const location = useLocation();
const closeAll = useUIStore((state) => state.closeAll);

useEffect(() => {
  closeAll(); // закриває меню і будь-які відкриті модалки при зміні роуту
}, [location.pathname, closeAll]);
```

──────

### 4. Автозакриття при переході з мобільного на десктоп (resize > 768px)

Якщо користувач розгорнув вікно браузера, меню не повинно залишатися відкритим під капотом:

```ts
// Можна додати слухач один раз прямо під час ініціалізації
if (typeof window !== 'undefined') {
  const mediaQuery = window.matchMedia('(min-width: 768px)');
  mediaQuery.addEventListener('change', (e) => {
    if (e.matches) {
      useUIStore.getState().closeMobileMenu(); // виклик стора поза компонентами React!
    }
  });
}
```

(Зверніть увагу: `useUIStore.getState()` дозволяє читати та змінювати стан будь-де без хуків — навіть у чистих js/ts файлах чи колбеках).
──────

### 5. Підхід "Slices" (якщо UI розростається на 20+ станів)

Якщо в одному сторі змішуються тема, модалки, тоасти і дровери, їх розбивають на слайси:

```txt
    src/stores/
    ├── slices/
    │   ├── modal.slice.ts
    │   ├── menu.slice.ts
    │   └── toast.slice.ts
    └── ui.store.ts # збирає всі слайси в єдиний хук useUIStore
```

Приклад об'єднання:

```ts
export const useUIStore = create<MenuSlice & ModalSlice>()((...a) => ({
  ...createMenuSlice(...a),
  ...createModalSlice(...a),
}));
```

### Підсумок

• Усі правила взаємодії (закрити меню при відкритті модалки, скинути стан) тримаємо всередині методів стора.
• Поза React-компонентами (в івентах, роутах) використовуємо швидкий доступ: `useUIStore.getState().closeAll()`.
