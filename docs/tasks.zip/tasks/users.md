# Users

## GET /users/me

Request:
    Headers: Authorization: Bearer <token>
Response:
    Статус: 200 OK
    Body (JSON):

        ```json
        {
            "user": {
                "id": "64f1a2b3c4d5e6f7a8b9c0d1",
                "name": "Panda",
                "email": "panda@panda.com",
                "avatar": "https://res.cloudinary.com/.../avatar.jpg"
            },
            "recipesCount": 12,
            "favoritesCount": 5,
            "followersCount": 48,
            "followingCount": 15
        }
        ```

---

## PATCH /users/me/avatar

Request:
    Headers:
        Authorization: Bearer <token>
        Content-Type: multipart/form-data
    Body (form-data):
        avatar: binary file (зображення: jpg, png, webp; max 5MB)
Response:
    Статус: 200 OK
    Body (JSON):

        ```json
        {
            "user": {
                "id": "64f1a2b3c4d5e6f7a8b9c0d1",
                "name": "Panda",
                "email": "panda@panda.com",
                "avatar": "https://res.cloudinary.com/.../avatar.jpg"
            },
            "recipesCount": 12,
            "favoritesCount": 5,
            "followersCount": 48,
            "followingCount": 15
        }
        ```

---

## GET /users/me/following

Request:
    Headers: Authorization: Bearer <token>
    Query Params (опціонально): page (number, default: 1), limit (number, default: 5)
Response:
    Статус: 200 OK
    Body (JSON):
        ```json
        {
        "total": 1,
        "page": 1,
        "totalPages": 1,
        "perPage": 5,
        "followers": [
            {
                "user": {
                    "id": "64f1a2b3c4d5e6f7a8b9c0d1",
                    "name": "Panda",
                    "email": "panda@panda.com",
                    "avatar": "https://res.cloudinary.com/.../avatar.jpg"
                },
                "recipesCount": 2,
                "topRecipes": [
                    {
                        "id": "64f1a2b3c4d5e6f7a8b9c0d2",
                        "title": "Recipe 1",
                        "image": "https://res.cloudinary.com/.../recipe1.jpg"
                    },
                    {
                        "id": "64f1a2b3c4d5e6f7a8b9c0d3",
                        "title": "Recipe 2",
                        "image": "https://res.cloudinary.com/.../recipe2.jpg"
                    }
                ]
            }
        ]
        }
        ```

---

## POST /users/me/following/:id

Request:
    Headers: Authorization: Bearer <token>
    Path Params: id (string, max 32 символи)
Response:
    Статус: 200 OK
    Body (JSON):
        ```json
        {
            "message": "Successfully followed the user."
        }
        ```

---

## DELETE /users/me/following/:id

Request:
    Headers: Authorization: Bearer <token>
    Path Params: id (string, max 32 символи)
Response:
    Статус: 200 OK
    Body (JSON):
        ```json
        {
            "message": "Successfully unfollowed the user."
        }
        ```

---

## GET /users/:id

Request:

    Path Params: id (string, max 32 символи)

Response:

    Статус: 200 OK
    Body (JSON):
        ```json
        {
        "user": {
            "id": "64f1a2b3c4d5e6f7a8b9c0d1",
            "name": "Panda",
            "email": "panda@panda.com",
            "avatar": "https://res.cloudinary.com/.../avatar.jpg"
        },
        "recipesCount": 12,
        "followersCount": 48,
        }
        ```
---

## GET /users/:id/followers

Request:
    Path Params: id (string, max 32 символи)
    Query Params (опціонально): page (number, default: 1), limit (number, default: 5)
Response:
    Статус: 200 OK
    Body (JSON):
        ```json
        {
        "total": 1,
        "page": 1,
        "totalPages": 1,
        "perPage": 5,
        "followers": [
            {
                "user": {
                    "id": "64f1a2b3c4d5e6f7a8b9c0d1",
                    "name": "Panda",
                    "email": "panda@panda.com",
                    "avatar": "https://res.cloudinary.com/.../avatar.jpg"
                },
                "recipesCount": 2,
                "topRecipes": [
                    {
                        "id": "64f1a2b3c4d5e6f7a8b9c0d2",
                        "title": "Recipe 1",
                        "image": "https://res.cloudinary.com/.../recipe1.jpg"
                    },
                    {
                        "id": "64f1a2b3c4d5e6f7a8b9c0d3",
                        "title": "Recipe 2",
                        "image": "https://res.cloudinary.com/.../recipe2.jpg"
                    }
                ]
            }
        ]
        }
        ```

---

## GET /users/:id/recipes

Request:

    Path Params: id (string, max 32 символи)
    Query Params (опціонально): page (number, default: 1), limit (number, default: 10)
Response:

    Статус: 200 OK
    Body (JSON):
        ```json
        {
        "total": 1,
        "page": 1,
        "totalPages": 1,
        "perPage": 10,
        "recipes": [
            {
                "id": "64f1a2b3c4d5e6f7a8b9c0d2",
                "title": "Recipe 1",
                "image": "https://res.cloudinary.com/.../recipe1.jpg",
                "shortDescription": "Short description of Recipe 1"
            },
            {
                "id": "64f1a2b3c4d5e6f7a8b9c0d3",
                "title": "Recipe 2",
                "image": "https://res.cloudinary.com/.../recipe2.jpg",
                "shortDescription": "Short description of Recipe 2"
            }
        ]
        }
        ```
---
