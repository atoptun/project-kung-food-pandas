Це класична ситуація у фронтенд-розробці.

TanStack Query НЕ керує станом інпутів/фільтрів — він лише виконує запит на основі переданого queryKey.

Щоб зв'язати фільтри з віддаленим списком результатів, є два найкращих підходи:
──────

### Підхід 1: URL Query Search Params (Найбільш рекомендований 🏆)

Зберігати значення фільтрів (category, ingredient, area, page) прямо в URL браузера:
`https://foodies.com/recipes?category=Beef&page=2`

#### Чому це найкраще рішення:

1. Збереження стану: Якщо користувач оновить сторінку (F5) або скине посилання другові — відкриється той самий відфільтрований результат.
2. Кнопка "Назад": Браузерні кнопки «Назад/Вперед» повертають попередні фільтри.
3. Жодних зайвих глобальних сторів: react-router уже є у додатку.

#### Як це реалізувати:

1.  Компонент фільтрів (RecipeFilters.tsx) — лише записує в URL:

```tsx
import { useSearchParams } from 'react-router';

export function RecipeFilters() {
  const [searchParams, setSearchParams] = useSearchParams();

  const handleCategoryChange = (category: string) => {
    setSearchParams((prev) => {
      // При зміні фільтра завжди скидаємо сторінку на 1 (вимога ТЗ)
      prev.set('page', '1');
      if (category) {
        prev.set('category', category);
      } else {
        prev.delete('category');
      }
      return prev;
    });
  };

  return (
    <Select
      value={searchParams.get('category') || ''}
      onValueChange={handleCategoryChange}
      // ...
    />
  );
}
```

2. Компонент результатів (RecipeList.tsx) — лише читає з URL і викликає хук:

```tsx
import { useSearchParams } from 'react-router';
import { useRecipes } from '@/features/recipes/api/useRecipes';

export function RecipeList() {
  const [searchParams] = useSearchParams();

  // Читаємо параметри прямо з URL
  const category = searchParams.get('category') || undefined;
  const page = Number(searchParams.get('page')) || 1;

  // Викликаємо хук. Коли фільтри змінять URL, цей компонент сам автоматично зробить запит!
  const { data, isLoading } = useRecipes({ category, page });

  if (isLoading) return <Spinner />;

  return (
    <div>
      {data.recipes.map((recipe) => (
        <RecipeCard key={recipe.id} recipe={recipe} />
      ))}
    </div>
  );
}
```

──────

### Підхід 2: Zustand Store для фільтрів (Якщо не хочете змінювати URL)

Якщо з якихось причин фільтри не мають відображатися в адресному рядку браузера:

1.  Створюємо маленький клієнтський стор для фільтрів:

```ts
// apps/web/src/features/recipes/model/useRecipeFiltersStore.ts
import { create } from 'zustand';

interface RecipeFiltersState {
  category: string;
  ingredient: string;
  area: string;
  page: number;
  setCategory: (category: string) => void;
  setIngredient: (ingredient: string) => void;
  setArea: (area: string) => void;
  setPage: (page: number) => void;
  resetFilters: () => void;
}

export const useRecipeFiltersStore = create<RecipeFiltersState>((set) => ({
  category: '',
  ingredient: '',
  area: '',
  page: 1,
  setCategory: (category) => set({ category, page: 1 }), // скидаємо на 1-шу сторінку
  setIngredient: (ingredient) => set({ ingredient, page: 1 }),
  setArea: (area) => set({ area, page: 1 }),
  setPage: (page) => set({ page }),
  resetFilters: () => set({ category: '', ingredient: '', area: '', page: 1 }),
}));
```

3. Компонент фільтрів змінює Zustand стор:

```tsx
import { useRecipeFiltersStore } from '@/features/recipes/model/useRecipeFiltersStore';

export function RecipeFilters() {
  const { category, setCategory } = useRecipeFiltersStore();

  return (
    <Select
      value={category}
      onValueChange={setCategory}
      // ...
    />
  );
}
```

1. Компонент результатів підписується на цей же Zustand стор і передає значення в TanStack Query:

```tsx
import { useRecipeFiltersStore } from '@/features/recipes/model/useRecipeFiltersStore';
import { useRecipes } from '@/features/recipes/api/useRecipes';

export function RecipeList() {
  const { category, ingredient, area, page } = useRecipeFiltersStore();

  // Оскільки TanStack Query стежить за queryKey: ['recipes', { category, page, ... }],
  // зміна будь-якого поля у Zustand сторі автоматично запустить useRecipes з новими параметрами!
  const { data, isLoading } = useRecipes({ category, ingredient, area, page });

  if (isLoading) return <Spinner />;

  return (
    <div>
      {data.recipes.map((recipe) => (
        <RecipeCard key={recipe.id} recipe={recipe} />
      ))}
    </div>
  );
}
```

──────

### Що краще обрати?

• Для каталогів, пошуку та пагінації (як наша сторінка рецептів за ТЗ) — Підхід 1 (URL Search Params) є світовим стандартом у вебі.
• Якщо стан суто тимчасовий і не повинен бути в URL — Підхід 2 (Zustand).
