## Better Auth (Vercel -> Render)

У вас у app.ts вже зроблено майже все правильно (credentials: true, CORS_ORIGINS з .env).
Але чому /readyz проходить, а з авторизацією (куками) можуть виникнути проблеми:
• /readyz — це простий GET-запит без cookies.
• А для кук між Vercel та Render браузер вимагає особливих атрибутів SameSite=None; Secure, які на локалі (HTTP) ламають роботу, якщо не зробити динамічне перемикання через env.IS_PROD.
Ось чіткі кроки, що саме потрібно додати.
──────

### Крок 1. Налаштувати auth.ts для Better Auth

Вам треба передати trustedOrigins (щоб Better Auth довіряв Vercel) та налаштувати advanced.defaultCookieAttributes залежно від середовища (production чи
development):

```ts
// apps/api/src/lib/auth.ts
import { betterAuth } from 'better-auth';
import { prismaAdapter } from 'better-auth/adapters/prisma';
import { bearer, openAPI } from 'better-auth/plugins';

import env from '@/config/env';
import prisma from '@/lib/prisma';

export const auth = betterAuth({
  database: prismaAdapter(prisma, {
    provider: 'postgresql',
  }),
  secret: env.BETTER_AUTH_SECRET,
  baseURL: env.BETTER_AUTH_URL,
  // 1. Дозволені домени для Better Auth (CORS/Redirect checks)
  trustedOrigins: env.CORS_ORIGINS,
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // 1 day
  },
  advanced: {
    database: {
      joins: true,
    },
    // 2. Куки: у production потрібні SameSite=none і Secure=true для Vercel -> Render
    // На локалі (HTTP) SameSite=none браузери відхиляють, тому там залишаємо lax
    useSecureCookies: env.IS_PROD,
    crossSubDomainCookies: {
      enabled: false,
    },
    defaultCookieAttributes: env.IS_PROD
      ? {
          sameSite: 'none',
          secure: true,
          httpOnly: true,
        }
      : {
          sameSite: 'lax',
          secure: false,
          httpOnly: true,
        },
  },
  user: {
    fields: {
      image: 'avatar',
    },
  },
  emailAndPassword: {
    enabled: true,
  },
  plugins: [bearer(), openAPI()],
});
```

──────

### Крок 2. Змінні оточення (.env)

У вас уже є чудовий механізм парсингу `CORS_ORIGINS` через кому в `env.ts`.

#### Локально (.env.local в корені проєкту):

```env
    NODE_ENV=development
    PORT=4000
    BETTER_AUTH_URL=http://localhost:4000
    CORS_ORIGINS=http://localhost:5173,http://localhost:3000
```

#### На Render (Dashboard -> Environment):

Вам потрібно додати або оновити 2 змінні:

```env
NODE_ENV=production
BETTER_AUTH_URL=https://project-kung-food-pandas.onrender.com
CORS_ORIGINS=https://your-frontend.vercel.app,http://localhost:5173
```

(Якщо фронтенд має кілька доменів, наприклад preview-версії на Vercel, перелічіть їх через кому: https://your-app.vercel.app,https://your-app-git-dev.vercel.app).
──────

### Крок 3. На фронтенді (apps/web)

Щоб браузер відправляв і зберігав куки при міждоменних запитах:

#### Для клієнта better-auth/react:

Створіть клієнт, де базовий URL береться з env:

```ts
// apps/web/src/lib/auth-client.ts
import { createAuthClient } from 'better-auth/react';

export const authClient = createAuthClient({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:4000',
  fetchOptions: {
    credentials: 'include', // ОБОВ'ЯЗКОВО для пересилання cookies між доменами!
  },
});
```

• Ви використовуєте рідний хук Better Auth:

```ts
import { authClient } from '@/lib/auth-client';

function UserBar() {
  const { data: session } = authClient.useSession();
  // якщо session є — юзер залогінений
}
```

#### Для звичайних запитів (Axios або Fetch):

Якщо ви робите запити до інших ендпоінтів (/recipes, /users), обов'язково увімкніть credentials:

```ts
// apps/web/src/lib/api.ts
import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:4000',
  withCredentials: true, // ОБОВ'ЯЗКОВО!
});
```

#### Змінні на фронтенді:

• Локально (apps/web/.env):
`VITE_API_URL=http://localhost:4000`
• На Vercel (Project Settings -> Environment Variables):
`VITE_API_URL=https://project-kung-food-pandas.onrender.com`

──────

### Що це дає:

1. Локально: Куки передаються по незахищеному http://localhost:5173 -> http://localhost:4000 без конфліктів Secure.
2. У продакшені (Vercel -> Render): Куки автоматично стають SameSite=None; Secure=true, а браузер передає їх завдяки credentials: 'include'.
