CREATE TABLE areas (
    id VARCHAR(24) PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);


CREATE TABLE categories (
    id VARCHAR(24) PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE ingredients (
    id VARCHAR(24) PRIMARY KEY,
    name VARCHAR(255),
    description TEXT, -- Обов'язково TEXT
    img TEXT
);

CREATE TABLE testimonials (
    id VARCHAR(24) PRIMARY KEY,       -- ID самого відгуку
    owner_id VARCHAR(24) NOT NULL,    -- ID користувача, що залишив відгук
    testimonial TEXT NOT NULL         -- Текст відгуку
);

CREATE TABLE users (
    id VARCHAR(24) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    avatar TEXT
);

-- 1. Таблиця рецептів
CREATE TABLE recipes (
    id VARCHAR(24) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    area VARCHAR(100),
    instructions TEXT,
    description TEXT,
    thumb TEXT,
    preview TEXT,
    time INTEGER,
    owner_id VARCHAR(24) REFERENCES users(id) -- Зв'язок з автором
);

-- 2. Таблиця зв'язків (Many-to-Many)
CREATE TABLE recipe_ingredients (
    recipe_id VARCHAR(24) REFERENCES recipes(id) ON DELETE CASCADE,
    ingredient_id VARCHAR(24) REFERENCES ingredients(id),
    measure VARCHAR(100),
    PRIMARY KEY (recipe_id, ingredient_id)
);
