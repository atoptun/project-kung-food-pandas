Короткий план, як зв'язка Zustand + TanStack Query ідеально лягає на наш проєкт Kung Food Pandas (за вимогами frontend.md):
──────

### Чіткий розподіл ролей

    ┌────────────────────────────────────────────────────────┐
    │                   React Components                     │
    └───────────────┬────────────────────────┬───────────────┘
                    │                        │
           (Server Data: API)        (UI & Local State)
                    ▼                        ▼
         ┌────────────────────┐    ┌───────────────────┐
         │   TanStack Query   │    │      Zustand      │
         │                    │    │                   │
         │ • Recipes & Details│    │ • Auth Token & Me │
         │ • Categories/Areas │    │ • Active Modals   │
         │ • Testimonials     │    │ • Filter values   │
         │ • User Profiles    │    │ • Mobile Menu     │
         └────────────────────┘    └───────────────────┘

──────

### 1. За що відповідає Zustand (Тільки UI та Клієнтський стан)

Вам знадобиться всього 2–3 крихітних стори:

#### А. Стан користувача (useUserStore)

Зберігає інформацію про поточного користувача:

```ts
// apps/web/src/store/useUserStore.ts
import { create } from 'zustand';

interface UserState {
  id: string | null;
  name: string | null;
  email: string | null;
  avatar: string | null;
  setUser: (user: UserState) => void;
  clearUser: () => void;
}

export const useUserStore = create<UserState>()((set) => ({
  id: null,
  name: null,
  email: null,
  avatar: null,
  setUser: (user) => set(user),
  clearUser: () => set({ id: null, name: null, email: null, avatar: null }),
}));
```

#### Б. Стан модальних вікон (useModalStore)

Керує відкриттям SignInModal, SignUpModal, LogOutModal

```ts
// apps/web/src/store/useModalStore.ts
import { create } from 'zustand';

type ModalType = 'signIn' | 'signUp' | 'logOut' | null;

export const useModalStore = create<{
  modal: ModalType;
  openModal: (type: ModalType) => void;
  closeModal: () => void;
}>((set) => ({
  modal: null,
  openModal: (modal) => set({ modal }),
  closeModal: () => set({ modal: null }),
}));
```

──────

### 2. За що відповідає TanStack Query (Вся робота з API)

Всі запити до бекенда, кешування та автоматичне оновлення після мутацій.

#### А. Отримання даних (Queries) — наприклад, рецепти

```ts
// apps/web/src/api/recipes.ts
export const useRecipes = (params: { category?: string; page: number }) => {
  return useQuery({
    queryKey: ['recipes', params],
    queryFn: () => api.get('/recipes', { params }).then((res) => res.data),
    staleTime: 1000 * 60 * 5, // кешувати на 5 хвилин
  });
};
```

#### Б. Мутації з авто-оновленням списку (Mutations) — наприклад, видалення або лайк

Коли видалили рецепт або додали в улюблені, TanStack Query автоматично оновить дані на екрані:

```ts
export const useToggleFavorite = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (recipeId: string) => api.post(`/recipes/${recipeId}/favorite`),
    onSuccess: () => {
      // Миттєво інвалідує кеш: список улюблених та лічильник оновляться самі!
      queryClient.invalidateQueries({ queryKey: ['recipes'] });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
  });
};
```

──────

### Чому це вигідніше за Redux для цього проєкту?

1. Мінус 70% шаблонного коду (boilerplate): Не треба писати createSlice, extraReducers, pending/fulfilled/rejected для кожного ендпоінта.
2. Кешування з коробки: TanStack Query сам знає, коли перезапитати категорії чи інгредієнти, а коли взяти з пам'яті.
3. Легкість: Весь Zustand — це один файл, без потреби огортати додаток у `<Provider store={store}>`.
4. Ідеально виконує вимоги ТЗ: Легко закривати модалки, скидати пагінацію при зміні фільтрів і показувати спінери (isLoading).
